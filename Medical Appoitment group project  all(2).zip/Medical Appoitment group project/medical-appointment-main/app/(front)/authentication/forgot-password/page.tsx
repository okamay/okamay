import React from "react";

const Page = () => {
  return (
    <div className="min-h-screen py-[80px]">
      <div>
        <h2>Forgot Password</h2>
      </div>
    </div>
  );
};

export default Page;
