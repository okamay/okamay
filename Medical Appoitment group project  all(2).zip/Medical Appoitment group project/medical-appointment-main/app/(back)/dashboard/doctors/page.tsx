import React from "react";

const page = () => {
  return <div>Doctors Page</div>;
};

export default page;
