import Settings from "@/components/Dashboard/Settings/Settings";

const Page = () => {
  return (
    <div className="">
      <Settings />
    </div>
  );
};

export default Page;
