import ServiceForm from "@/components/ServiceForm";
import React from "react";

const page = () => {
  return (
    <div>
      <ServiceForm title="Create Service" />
    </div>
  );
};

export default page;
