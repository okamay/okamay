import Orders from "@/components/Dashboard/Orders/Orders";

const Page = () => {
  return (
    <div className="py-6">
      <Orders />
    </div>
  );
};

export default Page;
