import SpecialtyForm from "@/components/SpecialtyForm";
import React from "react";

const page = () => {
  return (
    <div>
      <SpecialtyForm title="Create Specialty" />
    </div>
  );
};

export default page;
