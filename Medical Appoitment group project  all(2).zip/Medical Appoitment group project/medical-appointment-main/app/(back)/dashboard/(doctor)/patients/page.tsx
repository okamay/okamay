import React from "react";

const page = () => {
  return (
    <div>
      <h2>Patients</h2>
    </div>
  );
};

export default page;
