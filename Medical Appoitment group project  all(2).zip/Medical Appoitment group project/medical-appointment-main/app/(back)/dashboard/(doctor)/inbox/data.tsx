import React from "react";

const data = () => {
  return (
    <div>
      <h2>Data</h2>
    </div>
  );
};

export default data;
