import React from "react";

const page = () => {
  return (
    <div>
      <h2>Inbox</h2>
    </div>
  );
};

export default page;
