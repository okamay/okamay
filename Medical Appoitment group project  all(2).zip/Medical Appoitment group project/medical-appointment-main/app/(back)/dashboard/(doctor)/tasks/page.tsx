import React from "react";

const page = () => {
  return (
    <div>
      <h2>Tasks</h2>
    </div>
  );
};

export default page;
