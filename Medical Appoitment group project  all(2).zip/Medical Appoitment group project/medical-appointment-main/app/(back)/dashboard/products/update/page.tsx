import EditProduct from "@/components/Dashboard/Products/EditProduct";
import React from "react";

const Page = () => {
  return (
    <div className="py-6">
      <EditProduct />
    </div>
  );
};

export default Page;
