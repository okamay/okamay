import Products from "@/components/Dashboard/Products/Products";
import React from "react";

const Page = () => {
  return (
    <div className="py-6">
      <Products />
    </div>
  );
};

export default Page;
