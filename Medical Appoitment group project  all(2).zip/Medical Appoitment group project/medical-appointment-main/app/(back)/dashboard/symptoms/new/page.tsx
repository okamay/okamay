import SymptomForm from "@/components/SymptomForm";
import React from "react";

const page = () => {
  return (
    <div>
      <SymptomForm title="Create Symptom" />
    </div>
  );
};

export default page;
