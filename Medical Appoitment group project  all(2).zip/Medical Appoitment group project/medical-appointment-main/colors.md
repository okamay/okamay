# Website colors

> Dark Background: bg-slate-900
> White Background: bg-[#f1f1f1]
> Headings: #002479
> Paragraph: #212529
> White: #ffffff
