import React from "react";

const PatientDashboard = () => {
  return <div>Patient Dashboard</div>;
};

export default PatientDashboard;
