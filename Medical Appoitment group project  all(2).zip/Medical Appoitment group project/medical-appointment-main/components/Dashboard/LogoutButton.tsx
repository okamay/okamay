import React from "react";
import { GoSignOut } from "react-icons/go";

const LogoutButton = () => {
  return (
    <div>
      <GoSignOut />
    </div>
  );
};

export default LogoutButton;
