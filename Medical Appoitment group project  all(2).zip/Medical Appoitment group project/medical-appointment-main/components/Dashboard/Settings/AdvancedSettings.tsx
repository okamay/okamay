import React from "react";

const AdvancedSettings = () => {
  return <div>AdvancedSettings</div>;
};

export default AdvancedSettings;
