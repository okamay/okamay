import React from "react";

const SecuritySettings = () => {
  return <div>SecuritySettings</div>;
};

export default SecuritySettings;
