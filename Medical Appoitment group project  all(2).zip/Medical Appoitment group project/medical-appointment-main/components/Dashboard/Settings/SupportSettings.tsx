import React from "react";

const SupportSettings = () => {
  return <div>SupportSettings</div>;
};

export default SupportSettings;
