import React from "react";

const IntegrationsSettings = () => {
  return <div>IntegrationsSettings</div>;
};

export default IntegrationsSettings;
