import React from "react";

const OrganizationSettings = () => {
  return <div>OrganizationSetting</div>;
};

export default OrganizationSettings;
