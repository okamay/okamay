import React from "react";

const DoctorDashboard = () => {
  return <div>Doctor Dashboard</div>;
};

export default DoctorDashboard;
